CHERING LINK — HTML + CSS + JAVASCRIPT + INDEXEDDB
===================================================
Tidak menggunakan PHP dan tidak membutuhkan MySQL.

FILE:
- index.html : beranda / daftar video
- login.html : login admin demo
- admin.html : upload, daftar, hapus, salin link
- watch.html : pemutar video
- assets/style.css : tampilan
- assets/app.js : IndexedDB helper
- README.txt : petunjuk

CARA MENJALANKAN:
1. Ekstrak ZIP ke folder.
2. Buka index.html di Chrome atau Edge.
3. Klik Admin.
4. Username demo: admin
   Password demo: admin123
5. Pilih file video, isi judul, lalu tekan Simpan video.
6. Video tampil di beranda dan daftar admin.
7. Klik Salin link untuk menyalin tautan halaman tonton.

PENYIMPANAN:
Video disimpan dalam IndexedDB pada browser/perangkat yang digunakan.
Login adalah demo frontend dan bukan perlindungan keamanan.
Link video tidak dapat menampilkan file video pada perangkat orang lain, karena file tidak diunggah ke internet.
Data browser bisa terhapus jika pengguna membersihkan data situs; simpan salinan asli video.
Untuk berbagi publik, dibutuhkan hosting/backend atau layanan penyimpanan video online.
