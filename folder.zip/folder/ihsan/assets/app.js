const DB_NAME = 'chering-link-local';
const DB_VERSION = 1;
const STORE = 'videos';

function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: 'id' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
async function listVideos() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const request = db.transaction(STORE, 'readonly').objectStore(STORE).getAll();
    request.onsuccess = () => resolve(request.result.sort((a,b) => b.createdAt-a.createdAt));
    request.onerror = () => reject(request.error);
  });
}
async function findVideo(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const request = db.transaction(STORE, 'readonly').objectStore(STORE).get(id);
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error);
  });
}
async function putVideo(video) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put(video);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error || new Error('Penyimpanan dibatalkan'));
  });
}
async function eraseVideo(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
function htmlSafe(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function dateLabel(timestamp) {
  return new Date(timestamp).toLocaleDateString('id-ID', {day:'2-digit', month:'short', year:'numeric'});
}
function watchUrl(id) {
  const url = new URL('watch.html', window.location.href);
  url.searchParams.set('id', id);
  return url.href;
}
async function copyValue(value) {
  try {
    await navigator.clipboard.writeText(value);
    alert('Link disalin. Ingat: video lokal hanya tersedia di browser ini.');
  } catch {
    window.prompt('Salin link ini:', value);
  }
}
function makeId() {
  return (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2));
}